function db_get_news() {
  var news = "2016/11/11\nNEWS\n";

  return news;
}

exports.db_get_news = db_get_news;