var database = require("./database");

function GetNews(response) {
  console.log("Request handler 'GetNews' was called.");

  var body = database.db_get_news();

  response.writeHead(200, {"Content-Type": "text/html"});
  response.write(body);
  response.end();
}

exports.GetNews = GetNews;